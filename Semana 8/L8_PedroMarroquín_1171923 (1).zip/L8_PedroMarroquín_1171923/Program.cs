﻿class laboratorio8
{
    static void Main(string[] args)

    {
        double Dinero;
        double Billete100 = 0;
        double Billete50 = 0;
        double Billete20 = 0;
        double Billete10 = 0;
        double Billete5 = 0;
        double Moneda1 = 0;
        double Centavo25 = 0;
        double Centavo1 = 0;
        Console.WriteLine(" Pedro Marroquin, Número de Carné 1171923 ");
        Console.WriteLine("Ingrese la cantidad total: ");
        Dinero = Convert.ToDouble(Console.ReadLine());

        if (Dinero >= 100)
        {
            Billete100 = Dinero / 100;
            Dinero = Dinero % 100;
        }

        if (Dinero >= 50)
        {
            Billete50 = Dinero / 50;
            Dinero = Dinero % 50;

        }

        if (Dinero >= 20)
        {
            Billete20 = Dinero / 20;
            Dinero = Dinero % 20;
        }

        if (Dinero >= 10)
        {
            Billete10 = Dinero / 10;
            Dinero = Dinero % 10;
        }

        if (Dinero >= 5)
        {
            Billete5 = Dinero / 5;
            Dinero = Dinero % 5;
        }

        if (Dinero >= 1)
        {
            Moneda1 = Dinero / 1;
            Dinero = Dinero % 1;
        }

        if (Dinero >= 0.25)
        {
            Centavo25 = Dinero / 0.25;
            Dinero = Dinero % 0.25;
        }

        if (Dinero >= 0.01)
        {
            Centavo1 = Dinero / 0.01;
            Dinero = Dinero % 0.01;
        }

        Console.WriteLine("Se necesitan " + Math.Truncate(Billete100) + " billetes de 100");
        Console.WriteLine("Se necesitan " + Math.Truncate(Billete50) + " billetes de 50");
        Console.WriteLine("Se necesitan " + Math.Truncate(Billete20) + " billetes de 20");
        Console.WriteLine("Se necesitan " + Math.Truncate(Billete10) + " billetes de 10");
        Console.WriteLine("Se necesitan " + Math.Truncate(Billete5) + " billetes de 5");
        Console.WriteLine("Se necesitan " + Math.Truncate(Moneda1) + " monedas de 1");
        Console.WriteLine("Se necesitan " + Math.Truncate(Centavo25) + " monedas de 25 centavos");
        Console.WriteLine("Se necesitan " + Math.Truncate(Centavo1) + " centavos");

        Console.ReadKey();
    }
}




