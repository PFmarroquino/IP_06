﻿class program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Ingrese su nombre");
        String Nombre = Console.ReadLine();
        Console.WriteLine("Hola mundo ");
        Console.WriteLine("soy "+Nombre);
            /*
             Comentarios
            */
        Console.Write("Hola mundo ");
        Console.Write("soy "+ Nombre);
        Console.ReadKey();
    }
}
