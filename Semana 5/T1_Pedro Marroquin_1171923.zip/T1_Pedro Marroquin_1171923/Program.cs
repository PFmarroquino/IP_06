﻿class program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Mi segundo programa");
        string sNombre, sEdad, sCarrera, sCarne;
        Console.WriteLine("Ingrese nombre ");
        sNombre = Console.ReadLine();
        Console.WriteLine("\nIngrese su edad ");
            sEdad = Console.ReadLine();
        Console.WriteLine(" \nIngrese su carrera ");
        sCarrera = Console.ReadLine();
        Console.WriteLine("Ingrese su carne ");
        sCarne = Console.ReadLine();
        Console.WriteLine("Nombre " + sNombre);
        Console.WriteLine("Edad " + sEdad);
        Console.WriteLine("Carrera " + sCarrera);
        Console.WriteLine("Carne " + sCarne);

        Console.WriteLine("Soy " + sNombre + " tengo " + sEdad + " años y estudio la carrera de " + sCarrera + " mi numero de carne es " + sCarne);
        Console.ReadKey();
    }

}