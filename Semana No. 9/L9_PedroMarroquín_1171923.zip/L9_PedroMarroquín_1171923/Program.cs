﻿class Program

{
    public static double dMonto;
    public static double dDescuento;
    public static double dPorcentaje;
    public static double nCodigo;
    public static double dMontofinal;

    public static void Main()
    {
        Console.WriteLine(" Programa laboratorio #9 ");
        // se ingresa el monto total
        string sMonto;
        Console.WriteLine(" Bienvenido a nuestra tienda, por favor ingrese el monto total a pagar ");
        sMonto = Console.ReadLine();
        while (!double.TryParse(sMonto, out dMonto))
        {
            Console.WriteLine("Ingrese monto en formato correcto, ejemplo: 0.00");
            sMonto = Console.ReadLine();
        }
        if (dMonto <= 400)
        {
            dDescuento = 0;
            dPorcentaje = 0;
        }
        else if (dMonto <= 1000)
        {
            dDescuento = dMonto * 0.07;
            dPorcentaje = 7;
        }
        else if (dMonto <= 5000)
        {
            dDescuento = dMonto * 0.10;
            dPorcentaje = 10;
        }
        else if (dMonto <= 15000)
        {
            dDescuento = dMonto * 0.15;
            dPorcentaje = 15;
        }
        else if (dMonto > 15000)
        {
            dDescuento = dMonto * 0.25;
            dPorcentaje = 25;
        }

        MuestraDescuento(dMonto, dMontofinal);

    }
    public static void MuestraDescuento(double dMonto, double dMontofinal)
    {
        string Codigo = "";
        Console.WriteLine(" Posee un codigo de descuento? Escriba Si o No ");
        Codigo = Console.ReadLine();
        if (Codigo == "Si")
        {
            nCodigo = dMonto * 0.05;
            double Descuento = 5;
            double Montocondescuento = dMonto - nCodigo - dDescuento;
            double descuentofinal = Descuento + dPorcentaje;


            Console.WriteLine(" El descuento total a su compra es de: " + descuentofinal + "%" + " por lo que su saldo a pagar es de: " + Montocondescuento);
        }
        if (Codigo == "No")
        {
            double Montodescuento = dMonto - dDescuento;
            Console.WriteLine("El descuento para su compra es de: " + dPorcentaje + "%" + " por lo que su saldo a pagar es de: " + Montodescuento);
        }
    }

}





