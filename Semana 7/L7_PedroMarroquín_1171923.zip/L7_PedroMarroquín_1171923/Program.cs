﻿class laboratorio7
{
    static void Main(string[] args)

    {
        int num1 = 0;
        Console.WriteLine(" Ejercicio 1 ");
        Console.WriteLine(" Escriba un número entero ");
        num1 = Int32.Parse(Console.ReadLine());
 
        if (num1 < 0)
        {
            Console.WriteLine(" Resultado: El número ingresado es negativo");
        }
        else if (num1 == 0)
        {
            Console.WriteLine(" Resultado: El número ingresado es igual a cero ");
        }
        else if (num1>0)
        {
            Console.WriteLine(" Resultado: El número ingresado es positivo ");
        }
        else 
        {
            Console.WriteLine(" Escriba un numero válido");
        }
        Console.ReadKey();
        Console.Clear();
        //* Ejercicio 2 *//
        int dia = 0;
        Console.WriteLine(" Ejerecicio 2");
        Console.WriteLine(" Ingrese el número de dia ");
        dia = Int32.Parse(Console.ReadLine());

        switch (dia)
        {
            case 1:
                Console.WriteLine(" Dia lunes ");
                break;
            case 2:
                Console.WriteLine(" Dia martes ");
                break;
            case 3:
                Console.WriteLine(" Dia miercoles ");
                break;
            case 4:
                Console.WriteLine(" Dia jueves ");
                break;
            case 5:
                Console.WriteLine(" Dia viernes ");
                break;
            case 6:
                Console.WriteLine(" Dia sabado ");
                break;
            case 7:
                Console.WriteLine(" Dia domingo ");
                break;
        }
    }
}