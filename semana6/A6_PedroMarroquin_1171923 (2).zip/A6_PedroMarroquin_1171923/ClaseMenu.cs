﻿
class ClaseMenu
{
    static void Main(string[] args)
    {
        Console.WriteLine("Mi programa, inventario de café");
        Console.WriteLine();
        Console.WriteLine("Seleccione un tipo de café");
        Console.WriteLine("Menu principal");
        Console.WriteLine("1. Arabigo");
        Console.WriteLine("2. Bourbon");
        Console.WriteLine("3. Pacamara");
        Console.WriteLine("4. Geisha");
        string SeleccionMenu;
        SeleccionMenu = Console.ReadLine();

      switch (SeleccionMenu)
        {
            case "1":
                Console.WriteLine("Usted seleccionó: " + SeleccionMenu + " Arabigo");
                break;

            case "2":
        Console.WriteLine("Usted seleccionó: " + SeleccionMenu + " Bourbon");
                break;
            case "3":
                Console.WriteLine("Usted seleccionó: " + SeleccionMenu + " Pacamara");
                break;
            case "4":
                Console.WriteLine("Usted seleccionó: " + SeleccionMenu + " Geisha");
                break;
            default:
                Console.WriteLine("Seleccione una opcion válida");
                break;
        }
        Console.ReadKey();

    }
    static int stmetododummy()
    {

        return 1;
    }
}