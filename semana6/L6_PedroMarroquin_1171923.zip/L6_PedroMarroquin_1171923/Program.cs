﻿using System.ComponentModel.Design;
using System.Diagnostics.CodeAnalysis;

class laboratorio7
{
    static void Main(string[] args)

    {
        double num1 = 0.1;
        double num2 = 0.1;
        Console.WriteLine(" Ejercicio 1: Operaciones aritmeticas ");
        Console.WriteLine(" Escriba un número entero ");
        num1 = Int32.Parse(Console.ReadLine());
        Console.WriteLine(" Escriba otro numero entero ");
        num2 = Int32.Parse(Console.ReadLine());

        double suma = (num1 + num2);
        double resta = (num1 - num2);
        double division = (num1 / num2);
        double residuo = (num1 % num2);
        double multi = (num1 * num2);

        Console.WriteLine("El resultado de " + num1 + " + " + num2 + " = " + suma);
        Console.WriteLine("El resultado de " + num1 + " - " + num2 + " = " + resta);
        Console.WriteLine("El resultado de " + num1 + " * " + num2 + " = " + multi);
        Console.WriteLine("El resultado de " + num1 + " / " + num2 + " = " + division);
        Console.WriteLine("El residuo de " + num1 + " / " + num2 + " = " + residuo);


        Console.ReadKey();
        Console.Clear();
        //* Ejercicio 2 *//
        Console.WriteLine(" Ejercicio 2: Operaciones boolenas ");
        bool mayor = (num1 > num2);
        bool menor = (num1 < num2);
        bool igual = (num1 == num2);

        if (mayor)
        {
            Console.WriteLine(num1 + " es mayor que " + num2);
        }
        else if (menor)
        {
            Console.WriteLine(num1 + " es menor que " + num2);
        }
        else if (igual)
        {
            Console.WriteLine(num1 + " es igual a " + num2);
        }
        else
        {
            Console.WriteLine(" Ingrese numeros aceptables ");
        }

        Console.ReadKey();

        //* Ejercicio 3 *//
        Console.Clear();
        Console.WriteLine(" Ejercicio: 3 ");
        double a = 0.1;
        double b = 0.1;
        double c = 0.1;

        Console.WriteLine(" Ingrese el factor a ");
        a = Int32.Parse(Console.ReadLine());
        Console.WriteLine(" Ingrese el factor b ");
        b = Int32.Parse(Console.ReadLine());
        Console.WriteLine(" Ingrese el factor c ");
        c = Int32.Parse(Console.ReadLine());
        double operacion1 = a * b + c;
        double operacion2 = a * (b + c);
        double operacion3 = a / (b * c);
        double operacion4 = (3 * a + 2 * b) / c * c;

        Console.WriteLine(" El resultado de la primera operacion es: " + operacion1);
        Console.WriteLine(" El resultado de la segunda operacion es: " + operacion2);
        Console.WriteLine(" El resultado de la tercera operacion es: " + operacion3);
        Console.WriteLine(" El resultado de la cuarta operacion es: " + operacion4);

        //* Ecuacion cuadratica *//

        double op1 = (b * b) - 4*(a * c);
        double op2 = 2 * a;
        double op3 = Math.Sqrt(op1);
        double op4 = (-b + op3) / op2;
        double op5 = (-b - op3) / op2;
        if (a ==0)
            {
            Console.WriteLine(" El primer termino no puede ser igual a cero ");
        }
        else if ( op1 <= 0)
        {
            Console.WriteLine(" No es posible calcular una raiz negativa ");
        }
        else 
        {
            Console.WriteLine(" Los resultados para la ecuacion cuadratica de los tres factores es: " + op4 + " y " + op5);
        }
        
    }
}