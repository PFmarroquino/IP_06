﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Finca_Don_Pedro
{
    public class manualUsuario
    {
        public void mUsuario()
        {
            Console.Clear();
            Console.WriteLine("OPCIONES DEL PROGRAMA: ");
            Console.WriteLine("\n   En el programa se puede elegir el tipo de cafe que se desea consultar \n" +
                              "     entre las siguientes opciones:" +
                              "\n       1. Arabigo" +
                              "\n       2. Robusta" +
                              "\n       3. Bourbon" +
                              "\n       4. Pacamara" +
                              "\n       5. Gueisha\n");
            Console.WriteLine("Al elegir el tipo de cafe da un mejor control sobre el inventario, lo que es una lista ordenada de los productos" +
                              "que ofrece la empresa.");
            Console.WriteLine("\n\nLuego podra elegir dentro de cada tipo de cafe la presentacion de la que desea informacion entre:\n" +
                              "     1. Granulado\n" +
                              "     2. Molido\n");

            Console.WriteLine("Ademas que al elegir la opcion del cafe y la presentacion de la cual desea obtener informacion,\n" +
                              "dentro de la misma pestaña se mostrara el tiempo de produccion del mismo");

            Console.WriteLine("\nPROPOSITO: El propósito del programa es brindar al usuario un acceso facil al inventario y tiempo de produccion\n" +
                              "al mismo tiempo ofrecer una navegacion facil entre ventanas para poder un acceso rapido a esta informacion.\n" +
                              "Además que esta información es detallada segun el tipo de cafe y su presentacion, logrando asi un inventario\n" +
                              "detallado y agil para el usuario.");

            MPoS menuCierre=new MPoS();
            menuCierre.menuSalir();


        }
    }
}
