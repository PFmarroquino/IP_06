﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Finca_Don_Pedro
{
    public class MPoS
    {
        public void menuSalir()
        {
            string opcion;
            int op;

            Console.WriteLine("\nIngrese el numero de la accion a realizar:\n" +
                              " (1) Regresar al menu principal\n" +
                              " (2) Salir");

            opcion = Console.ReadLine();
            while ((opcion != "1" && opcion != "2" ) || !Int32.TryParse(opcion, out op))
            {
                Console.WriteLine("Ingrese una opcion valida");
                opcion = Console.ReadLine();
            }

            switch(op)
            {
                case 1:
                    menuPrincipal menu = new menuPrincipal();
                    Console.Clear();
                    menu.mPrincipal();
                    break;
                case 2:
                    Console.WriteLine("PRESIONE DOS VECES ENTER PARA CERRAR EL PROGRAMA");
                    break;
            }
        }
    }
}
