﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Finca_Don_Pedro
{
    public class creditosPrograma
    {
        public void creditos()
        {
            Console.WriteLine("Nombre del Proyecto: Finca don Pedro - Inventario y Tiempo de Procesos\n");
            Console.WriteLine("Fecha de creación: 24/10/2023\n");
            Console.WriteLine("Estimado de horas invertidas en la creación del programa: 1h\n");
            Console.WriteLine("Autores:\n");
            Console.WriteLine("     Carlos Rodrigo Montenegro Marroquín\n" +
                              "     1019923\n" +
                              "     Ingeniería Industrial\n" +
                              "\n" +
                              "     Pedro Fernando Marroquín Orozco\n" +
                              "     1171923\n" +
                              "     Ingenieria Industrial\n");

            MPoS mPoS = new MPoS();

            mPoS.menuSalir();
        }
    }
}
